﻿namespace tryA
{
    partial class Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.cmbCat = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtJan = new System.Windows.Forms.TextBox();
            this.txtFeb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtApr = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMay = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtJun = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtJul = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAug = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSep = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtOct = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtNov = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDec = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEvaluate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Description";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(369, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Category";
            // 
            // txtDes
            // 
            this.txtDes.Location = new System.Drawing.Point(15, 34);
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(276, 20);
            this.txtDes.TabIndex = 2;
           
            // 
            // cmbCat
            // 
            this.cmbCat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCat.FormattingEnabled = true;
            this.cmbCat.Items.AddRange(new object[] {
            "Utility",
            "Rent",
            "Food"});
            this.cmbCat.Location = new System.Drawing.Point(372, 34);
            this.cmbCat.Name = "cmbCat";
            this.cmbCat.Size = new System.Drawing.Size(139, 21);
            this.cmbCat.TabIndex = 4;
            this.cmbCat.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "JAN";
            // 
            // txtJan
            // 
            this.txtJan.Location = new System.Drawing.Point(15, 105);
            this.txtJan.Name = "txtJan";
            this.txtJan.Size = new System.Drawing.Size(57, 20);
            this.txtJan.TabIndex = 7;
            // 
            // txtFeb
            // 
            this.txtFeb.Location = new System.Drawing.Point(90, 105);
            this.txtFeb.Name = "txtFeb";
            this.txtFeb.Size = new System.Drawing.Size(57, 20);
            this.txtFeb.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "FEB";
            // 
            // txtMar
            // 
            this.txtMar.Location = new System.Drawing.Point(170, 105);
            this.txtMar.Name = "txtMar";
            this.txtMar.Size = new System.Drawing.Size(57, 20);
            this.txtMar.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(167, 89);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "MAR";
            // 
            // txtApr
            // 
            this.txtApr.Location = new System.Drawing.Point(246, 105);
            this.txtApr.Name = "txtApr";
            this.txtApr.Size = new System.Drawing.Size(57, 20);
            this.txtApr.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(243, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "APR";
            // 
            // txtMay
            // 
            this.txtMay.Location = new System.Drawing.Point(327, 105);
            this.txtMay.Name = "txtMay";
            this.txtMay.Size = new System.Drawing.Size(57, 20);
            this.txtMay.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(324, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "MAY";
            // 
            // txtJun
            // 
            this.txtJun.Location = new System.Drawing.Point(409, 105);
            this.txtJun.Name = "txtJun";
            this.txtJun.Size = new System.Drawing.Size(57, 20);
            this.txtJun.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(406, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "JUN";
            // 
            // txtJul
            // 
            this.txtJul.Location = new System.Drawing.Point(487, 105);
            this.txtJul.Name = "txtJul";
            this.txtJul.Size = new System.Drawing.Size(57, 20);
            this.txtJul.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(484, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "JUL";
            // 
            // txtAug
            // 
            this.txtAug.Location = new System.Drawing.Point(559, 105);
            this.txtAug.Name = "txtAug";
            this.txtAug.Size = new System.Drawing.Size(57, 20);
            this.txtAug.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(556, 89);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "AUG";
            // 
            // txtSep
            // 
            this.txtSep.Location = new System.Drawing.Point(625, 105);
            this.txtSep.Name = "txtSep";
            this.txtSep.Size = new System.Drawing.Size(57, 20);
            this.txtSep.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(622, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "SEP";
            // 
            // txtOct
            // 
            this.txtOct.Location = new System.Drawing.Point(691, 105);
            this.txtOct.Name = "txtOct";
            this.txtOct.Size = new System.Drawing.Size(57, 20);
            this.txtOct.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(688, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "OCT";
            // 
            // txtNov
            // 
            this.txtNov.Location = new System.Drawing.Point(757, 105);
            this.txtNov.Name = "txtNov";
            this.txtNov.Size = new System.Drawing.Size(57, 20);
            this.txtNov.TabIndex = 27;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(754, 89);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "NOV";
            // 
            // txtDec
            // 
            this.txtDec.Location = new System.Drawing.Point(827, 105);
            this.txtDec.Name = "txtDec";
            this.txtDec.Size = new System.Drawing.Size(57, 20);
            this.txtDec.TabIndex = 29;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(824, 89);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "DEC";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnBack.Location = new System.Drawing.Point(118, 143);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(80, 33);
            this.btnBack.TabIndex = 30;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14});
            this.dataGridView1.Location = new System.Drawing.Point(12, 184);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1362, 345);
            this.dataGridView1.TabIndex = 31;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Description";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Category";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "January";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "February";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "March";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "April";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "May";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Jun";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "July";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "August";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "September";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "October";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "November";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.HeaderText = "December";
            this.Column14.Name = "Column14";
            // 
            // btnEvaluate
            // 
            this.btnEvaluate.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnEvaluate.Location = new System.Drawing.Point(15, 143);
            this.btnEvaluate.Name = "btnEvaluate";
            this.btnEvaluate.Size = new System.Drawing.Size(85, 33);
            this.btnEvaluate.TabIndex = 32;
            this.btnEvaluate.Text = "Evaluate";
            this.btnEvaluate.UseVisualStyleBackColor = false;
            this.btnEvaluate.Click += new System.EventHandler(this.button3_Click);
            // 
            // Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1370, 544);
            this.Controls.Add(this.btnEvaluate);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtDec);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtNov);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtOct);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtSep);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtAug);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtJul);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtJun);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtMay);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtApr);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtMar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtFeb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtJan);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbCat);
            this.Controls.Add(this.txtDes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Transaction";
            this.Text = "Transaction";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.ComboBox cmbCat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtJan;
        private System.Windows.Forms.TextBox txtFeb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtApr;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtJun;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtJul;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAug;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSep;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtOct;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNov;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtDec;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Button btnEvaluate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
    }
}